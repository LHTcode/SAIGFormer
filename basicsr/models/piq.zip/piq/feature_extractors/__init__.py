from piq.feature_extractors.fid_inception import InceptionV3

__all__ = ['InceptionV3']
